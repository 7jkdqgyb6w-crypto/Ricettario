---
title: Crêpes
slug: crepes
author: Pierre Piccotti
origin: Jacqueline PiccottiRicettaConsiderato le centinaia di ricette più o meno fantasiose
  disponibili su Web in merito alle Crêpes, spesso scritte "crepes", riporto la ricetta
  di famiglia (famiglia francese) che si tramanda da un centinaio di anni.Per gli
  ingredienti, poco da dire, salvo che la qualità dei prodotti incide parecchio.Uova
  del pollaio vicino, farina di qualità, limoni BIO, burro magari fatto in casa (ma
  non di malga), latte della mucca del contadino appena munto e bollito in casa...
  insomma come era ordinario in campagna un volta e oggi potrebbe essere estraordinario.Sbattere
  a lungo le uova sino ad avere un composto omogeneo di bianco e rosso.Aggiungere
  poco alla volta la farina e prima sbattere con la frusta, poi impastare con il cucchiaio,
  sino ad avere un impasto che tiene, io da ragazzo lo chiamavo "gomma da masticare".
  Impastare a lungo, in modo che non vi siano più eventuali grumi. Proprio la lavorazione
  li distrugge.Aggiungere una noce di burro fusa delicatamente ed inglobare. La densità
  non dovrebbe cambiare di molto, salvo essere un poco più elastica.Aggiungere in
  parti uguali acqua e farina molto lentamente (e non gelate) mescolando perché il
  tutto si amalgami lentamente, senza formare grumi per la fretta. Il risultato finale
  dovrà essere una pastella che possa colare ma non gocciolare.Aggiungere un pizzico
  di sale e alcune scorze di limone.Lasciare riposare diverse ore al fresco. Il giorno
  dopo saranno al top.Il riposo permette alla farina di continuare l'idratazione,
  infatti vedrete che la pastella si sarà notevolmente addensata e necessiterà di
  ulteriore diluizione. Più liquida sarà, più potranno essere sottili. Questioni di
  gusto.La padella, va bene quella che preferite. Una colta avevo una padella in ferro
  dedicata solo a questo. Consentiva delle sottili bruciature, forse non consigliabili,
  ma una volta apprezzate.Il fondo va preparato con o un poco di burro. Non si tratta
  di dare gusto, ma solo permettere un minimo di lubrificazione della superfice. Io
  poi passo sempre panno di carta per togliere eventuali eccessi.Versare con il mestolo
  la pastella (a temperatura ambiente) a giri concentrici per distribuire un velo
  su tutta la superfice ruotando ed inclinando la padella per riempire le lacune.
  Io le preferisco quando restano molto sottili, ma non come quelle secche che vendono
  agli angoli delle strade in Francia.Quando ha preso consistenza e sotto appare appena
  colorato, rivoltare al salto (più che bravura è una questione di padella) e continuare
  la cottura. Se non riesce, va benissimo una paletta sottile. Non dovrebbero esserci
  problemi staccare dalla padella, facilmente l'aria l'ha staccata per conto suo gonfiandola.Nella
  ricetta base aggiungere zucchero sulla superfice (se pensate di farle salate, ovviamente
  NO,  neppure se pensate a ferciture.Quando comincia a prendere un colore ambrato
  scuro e lo zucchero si è sciolto,arrotolare, o piegare a spicchi e servire caldo
  in piatto con un altro cucchiaino di zucchero.Si può discutere di ripieni, di Nutella,
  Suzette, salate, al Grand Marrnier, banane e rhum,  e altro ancora. Ottime ma è
  altro. Questa la base come a casa si faceva a casa mia.
source: Jacqueline PiccottiRicettaConsiderato le centinaia di ricette più o meno fantasiose
  disponibili su Web in merito alle Crêpes, spesso scritte "crepes", riporto la ricetta
  di famiglia (famiglia francese) che si tramanda da un centinaio di anni.Per gli
  ingredienti, poco da dire, salvo che la qualità dei prodotti incide parecchio.Uova
  del pollaio vicino, farina di qualità, limoni BIO, burro magari fatto in casa (ma
  non di malga), latte della mucca del contadino appena munto e bollito in casa...
  insomma come era ordinario in campagna un volta e oggi potrebbe essere estraordinario.Sbattere
  a lungo le uova sino ad avere un composto omogeneo di bianco e rosso.Aggiungere
  poco alla volta la farina e prima sbattere con la frusta, poi impastare con il cucchiaio,
  sino ad avere un impasto che tiene, io da ragazzo lo chiamavo "gomma da masticare".
  Impastare a lungo, in modo che non vi siano più eventuali grumi. Proprio la lavorazione
  li distrugge.Aggiungere una noce di burro fusa delicatamente ed inglobare. La densità
  non dovrebbe cambiare di molto, salvo essere un poco più elastica.Aggiungere in
  parti uguali acqua e farina molto lentamente (e non gelate) mescolando perché il
  tutto si amalgami lentamente, senza formare grumi per la fretta. Il risultato finale
  dovrà essere una pastella che possa colare ma non gocciolare.Aggiungere un pizzico
  di sale e alcune scorze di limone.Lasciare riposare diverse ore al fresco. Il giorno
  dopo saranno al top.Il riposo permette alla farina di continuare l'idratazione,
  infatti vedrete che la pastella si sarà notevolmente addensata e necessiterà di
  ulteriore diluizione. Più liquida sarà, più potranno essere sottili. Questioni di
  gusto.La padella, va bene quella che preferite. Una colta avevo una padella in ferro
  dedicata solo a questo. Consentiva delle sottili bruciature, forse non consigliabili,
  ma una volta apprezzate.Il fondo va preparato con o un poco di burro. Non si tratta
  di dare gusto, ma solo permettere un minimo di lubrificazione della superfice. Io
  poi passo sempre panno di carta per togliere eventuali eccessi.Versare con il mestolo
  la pastella (a temperatura ambiente) a giri concentrici per distribuire un velo
  su tutta la superfice ruotando ed inclinando la padella per riempire le lacune.
  Io le preferisco quando restano molto sottili, ma non come quelle secche che vendono
  agli angoli delle strade in Francia.Quando ha preso consistenza e sotto appare appena
  colorato, rivoltare al salto (più che bravura è una questione di padella) e continuare
  la cottura. Se non riesce, va benissimo una paletta sottile. Non dovrebbero esserci
  problemi staccare dalla padella, facilmente l'aria l'ha staccata per conto suo gonfiandola.Nella
  ricetta base aggiungere zucchero sulla superfice (se pensate di farle salate, ovviamente
  NO,  neppure se pensate a ferciture.Quando comincia a prendere un colore ambrato
  scuro e lo zucchero si è sciolto,arrotolare, o piegare a spicchi e servire caldo
  in piatto con un altro cucchiaino di zucchero.Si può discutere di ripieni, di Nutella,
  Suzette, salate, al Grand Marrnier, banane e rhum,  e altro ancora. Ottime ma è
  altro. Questa la base come a casa si faceva a casa mia.
category: pasta e primi
photos:
- foto/feed/crepes/01
- foto/feed/crepes/02
codes:
  geo:
  - geo/jacqueline-piccottiricettaconsiderato-le-centinaia-di-ricette-piu-o-meno-fantasiose-disponibili-su-web-in-merito-alle-crepes-spesso-scritte-crepes-riporto-la-ricetta-di-famiglia-famiglia-francese-che-si-tramanda-da-un-centinaio-di-anni-per-gli-ingredienti-poco-da-dire-salvo-che-la-qualita-dei-prodotti-incide-parecchio-uova-del-pollaio-vicino-farina-di-qualita-limoni-bio-burro-magari-fatto-in-casa-ma-non-di-malga-latte-della-mucca-del-contadino-appena-munto-e-bollito-in-casa-insomma-come-era-ordinario-in-campagna-un-volta-e-oggi-potrebbe-essere-estraordinario-sbattere-a-lungo-le-uova-sino-ad-avere-un-composto-omogeneo-di-bianco-e-rosso-aggiungere-poco-alla-volta-la-farina-e-prima-sbattere-con-la-frusta-poi-impastare-con-il-cucchiaio-sino-ad-avere-un-impasto-che-tiene-io-da-ragazzo-lo-chiamavo-gomma-da-masticare-impastare-a-lungo-in-modo-che-non-vi-siano-piu-eventuali-grumi-proprio-la-lavorazione-li-distrugge-aggiungere-una-noce-di-burro-fusa-delicatamente-ed-inglobare-la-densita-non-dovrebbe-cambiare-di-molto-salvo-essere-un-poco-piu-elastica-aggiungere-in-parti-uguali-acqua-e-farina-molto-lentamente-e-non-gelate-mescolando-perche-il-tutto-si-amalgami-lentamente-senza-formare-grumi-per-la-fretta-il-risultato-finale-dovra-essere-una-pastella-che-possa-colare-ma-non-gocciolare-aggiungere-un-pizzico-di-sale-e-alcune-scorze-di-limone-lasciare-riposare-diverse-ore-al-fresco-il-giorno-dopo-saranno-al-top-il-riposo-permette-alla-farina-di-continuare-l-idratazione-infatti-vedrete-che-la-pastella-si-sara-notevolmente-addensata-e-necessitera-di-ulteriore-diluizione-piu-liquida-sara-piu-potranno-essere-sottili-questioni-di-gusto-la-padella-va-bene-quella-che-preferite-una-colta-avevo-una-padella-in-ferro-dedicata-solo-a-questo-consentiva-delle-sottili-bruciature-forse-non-consigliabili-ma-una-volta-apprezzate-il-fondo-va-preparato-con-o-un-poco-di-burro-non-si-tratta-di-dare-gusto-ma-solo-permettere-un-minimo-di-lubrificazione-della-superfice-io-poi-passo-sempre-panno-di-carta-per-togliere-eventuali-eccessi-versare-con-il-mestolo-la-pastella-a-temperatura-ambiente-a-giri-concentrici-per-distribuire-un-velo-su-tutta-la-superfice-ruotando-ed-inclinando-la-padella-per-riempire-le-lacune-io-le-preferisco-quando-restano-molto-sottili-ma-non-come-quelle-secche-che-vendono-agli-angoli-delle-strade-in-francia-quando-ha-preso-consistenza-e-sotto-appare-appena-colorato-rivoltare-al-salto-piu-che-bravura-e-una-questione-di-padella-e-continuare-la-cottura-se-non-riesce-va-benissimo-una-paletta-sottile-non-dovrebbero-esserci-problemi-staccare-dalla-padella-facilmente-l-aria-l-ha-staccata-per-conto-suo-gonfiandola-nella-ricetta-base-aggiungere-zucchero-sulla-superfice-se-pensate-di-farle-salate-ovviamente-no-neppure-se-pensate-a-ferciture-quando-comincia-a-prendere-un-colore-ambrato-scuro-e-lo-zucchero-si-e-sciolto-arrotolare-o-piegare-a-spicchi-e-servire-caldo-in-piatto-con-un-altro-cucchiaino-di-zucchero-si-puo-discutere-di-ripieni-di-nutella-suzette-salate-al-grand-marrnier-banane-e-rhum-e-altro-ancora-ottime-ma-e-altro-questa-la-base-come-a-casa-si-faceva-a-casa-mia
  fonte:
  - fonte/jacqueline-piccottiricettaconsiderato-le-centinaia-di-ricette-piu-o-meno-fantasiose-disponibili-su-web-in-merito-alle-crepes-spesso-scritte-crepes-riporto-la-ricetta-di-famiglia-famiglia-francese-che-si-tramanda-da-un-centinaio-di-anni-per-gli-ingredienti-poco-da-dire-salvo-che-la-qualita-dei-prodotti-incide-parecchio-uova-del-pollaio-vicino-farina-di-qualita-limoni-bio-burro-magari-fatto-in-casa-ma-non-di-malga-latte-della-mucca-del-contadino-appena-munto-e-bollito-in-casa-insomma-come-era-ordinario-in-campagna-un-volta-e-oggi-potrebbe-essere-estraordinario-sbattere-a-lungo-le-uova-sino-ad-avere-un-composto-omogeneo-di-bianco-e-rosso-aggiungere-poco-alla-volta-la-farina-e-prima-sbattere-con-la-frusta-poi-impastare-con-il-cucchiaio-sino-ad-avere-un-impasto-che-tiene-io-da-ragazzo-lo-chiamavo-gomma-da-masticare-impastare-a-lungo-in-modo-che-non-vi-siano-piu-eventuali-grumi-proprio-la-lavorazione-li-distrugge-aggiungere-una-noce-di-burro-fusa-delicatamente-ed-inglobare-la-densita-non-dovrebbe-cambiare-di-molto-salvo-essere-un-poco-piu-elastica-aggiungere-in-parti-uguali-acqua-e-farina-molto-lentamente-e-non-gelate-mescolando-perche-il-tutto-si-amalgami-lentamente-senza-formare-grumi-per-la-fretta-il-risultato-finale-dovra-essere-una-pastella-che-possa-colare-ma-non-gocciolare-aggiungere-un-pizzico-di-sale-e-alcune-scorze-di-limone-lasciare-riposare-diverse-ore-al-fresco-il-giorno-dopo-saranno-al-top-il-riposo-permette-alla-farina-di-continuare-l-idratazione-infatti-vedrete-che-la-pastella-si-sara-notevolmente-addensata-e-necessitera-di-ulteriore-diluizione-piu-liquida-sara-piu-potranno-essere-sottili-questioni-di-gusto-la-padella-va-bene-quella-che-preferite-una-colta-avevo-una-padella-in-ferro-dedicata-solo-a-questo-consentiva-delle-sottili-bruciature-forse-non-consigliabili-ma-una-volta-apprezzate-il-fondo-va-preparato-con-o-un-poco-di-burro-non-si-tratta-di-dare-gusto-ma-solo-permettere-un-minimo-di-lubrificazione-della-superfice-io-poi-passo-sempre-panno-di-carta-per-togliere-eventuali-eccessi-versare-con-il-mestolo-la-pastella-a-temperatura-ambiente-a-giri-concentrici-per-distribuire-un-velo-su-tutta-la-superfice-ruotando-ed-inclinando-la-padella-per-riempire-le-lacune-io-le-preferisco-quando-restano-molto-sottili-ma-non-come-quelle-secche-che-vendono-agli-angoli-delle-strade-in-francia-quando-ha-preso-consistenza-e-sotto-appare-appena-colorato-rivoltare-al-salto-piu-che-bravura-e-una-questione-di-padella-e-continuare-la-cottura-se-non-riesce-va-benissimo-una-paletta-sottile-non-dovrebbero-esserci-problemi-staccare-dalla-padella-facilmente-l-aria-l-ha-staccata-per-conto-suo-gonfiandola-nella-ricetta-base-aggiungere-zucchero-sulla-superfice-se-pensate-di-farle-salate-ovviamente-no-neppure-se-pensate-a-ferciture-quando-comincia-a-prendere-un-colore-ambrato-scuro-e-lo-zucchero-si-e-sciolto-arrotolare-o-piegare-a-spicchi-e-servire-caldo-in-piatto-con-un-altro-cucchiaino-di-zucchero-si-puo-discutere-di-ripieni-di-nutella-suzette-salate-al-grand-marrnier-banane-e-rhum-e-altro-ancora-ottime-ma-e-altro-questa-la-base-come-a-casa-si-faceva-a-casa-mia
  ingr:
  - ingr/uova-allevate-a-terra
  - ingr/farina
  - ingr/burro-molto-fresco
  - ingr/latte-intero-anche-senza-lattosio
  - ingr/se-e-un-problema
  - ingr/acqua
  - ingr/sale
  - ingr/burro
  - ingr/zucchero-di-canna-chiaro-e-ben-macinato
  - ingr/limone-bio-si-usa-la-buccia
  tec:
  - tec/ripieno
---

## Ingredienti
- 2 uova allevate a terra
- farina 00
- burro molto fresco
- latte intero (anche senza lattosio
- se è un problema)
- acqua
- sale
- burro
- zucchero di canna chiaro e ben macinato
- limone BIO (si usa la buccia<9

## Preparazioni corrette
48. Crêpes
* Ingredienti:  2 uova allevate a terra, farina 00, burro molto fresco, latte intero (anche senza lattosio, se è un problema), acqua, sale, burro, zucchero di canna chiaro e ben macinato, limone BIO (si usa la buccia<9.* Preparazione: 20 minuti + cottura* Provenienza: Jacqueline PiccottiRicettaConsiderato le centinaia di ricette più o meno fantasiose disponibili su Web in merito alle Crêpes, spesso scritte "crepes", riporto la ricetta di famiglia (famiglia francese) che si tramanda da un centinaio di anni.Per gli ingredienti, poco da dire, salvo che la qualità dei prodotti incide parecchio.Uova del pollaio vicino, farina di qualità, limoni BIO, burro magari fatto in casa (ma non di malga), latte della mucca del contadino appena munto e bollito in casa... insomma come era ordinario in campagna un volta e oggi potrebbe essere estraordinario.Sbattere a lungo le uova sino ad avere un composto omogeneo di bianco e rosso.Aggiungere poco alla volta la farina e prima sbattere con la frusta, poi impastare con il cucchiaio, sino ad avere un impasto che tiene, io da ragazzo lo chiamavo "gomma da masticare". Impastare a lungo, in modo che non vi siano più eventuali grumi. Proprio la lavorazione li distrugge.Aggiungere una noce di burro fusa delicatamente ed inglobare. La densità non dovrebbe cambiare di molto, salvo essere un poco più elastica.Aggiungere in parti uguali acqua e farina molto lentamente (e non gelate) mescolando perché il tutto si amalgami lentamente, senza formare grumi per la fretta. Il risultato finale dovrà essere una pastella che possa colare ma non gocciolare.Aggiungere un pizzico di sale e alcune scorze di limone.Lasciare riposare diverse ore al fresco. Il giorno dopo saranno al top.Il riposo permette alla farina di continuare l'idratazione, infatti vedrete che la pastella si sarà notevolmente addensata e necessiterà di ulteriore diluizione. Più liquida sarà, più potranno essere sottili. Questioni di gusto.La padella, va bene quella che preferite. Una colta avevo una padella in ferro dedicata solo a questo. Consentiva delle sottili bruciature, forse non consigliabili, ma una volta apprezzate.Il fondo va preparato con o un poco di burro. Non si tratta di dare gusto, ma solo permettere un minimo di lubrificazione della superfice. Io poi passo sempre panno di carta per togliere eventuali eccessi.Versare con il mestolo la pastella (a temperatura ambiente) a giri concentrici per distribuire un velo su tutta la superfice ruotando ed inclinando la padella per riempire le lacune. Io le preferisco quando restano molto sottili, ma non come quelle secche che vendono agli angoli delle strade in Francia.Quando ha preso consistenza e sotto appare appena colorato, rivoltare al salto (più che bravura è una questione di padella) e continuare la cottura. Se non riesce, va benissimo una paletta sottile. Non dovrebbero esserci problemi staccare dalla padella, facilmente l'aria l'ha staccata per conto suo gonfiandola.Nella ricetta base aggiungere zucchero sulla superfice (se pensate di farle salate, ovviamente NO,  neppure se pensate a ferciture.Quando comincia a prendere un colore ambrato scuro e lo zucchero si è sciolto,arrotolare, o piegare a spicchi e servire caldo in piatto con un altro cucchiaino di zucchero.Si può discutere di ripieni, di Nutella, Suzette, salate, al Grand Marrnier, banane e rhum,  e altro ancora. Ottime ma è altro. Questa la base come a casa si faceva a casa mia.

## Tempi e temperature
20 minuti + cottura

## Correzioni di stile
Testo ripulito e separato nei campi del ricettario senza alterare il contenuto sostanziale.

## Note tecniche
Tecniche riconoscibili dal testo: ripieno.

## Note redazionali
Voce importata dal feed e normalizzata per il ricettario.

## Possibili miglioramenti
Eventuale precisazione di quantità, temperature o passaggi impliciti solo dove il post originale lo consenta.
