# Struttura sito pronta per pubblicazione

- contenuti/ricette/: 63 file markdown, uno per ricetta
- contenuti/indici/: indici ingredienti, geografia, tecniche, fonti
- foto/feed/: cartelle immagini da popolare con le foto dei post
- static/: risorse del sito
- admin/: punto di ingresso futuro del CMS

## Convenzioni foto
Per ogni ricetta:
- foto/feed/<slug>/01
- foto/feed/<slug>/02

## Convenzioni URL consigliate
- /ricette/<slug>/
- /indici/ingredienti/
- /indici/geografia/
- /indici/tecniche/
- /indici/fonti/
